<?php
$servername = "localhost";
$username= "u943657299_survey";
$password = "X*m3RngLl&:";
$db="u943657299_survey";

$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
  }


?>

